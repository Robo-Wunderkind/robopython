Welcome to robopython's documentation!
======================================

.. toctree::
   :maxdepth: 2
   :caption: Contents:

   readme
   installation
   usage
   bled112
   button
   light
   matrix
   motion
   motor
   rgb
   servo
   ultrasonic
   robo
   contributing
   authors
   history

Indices and tables
==================
* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`
