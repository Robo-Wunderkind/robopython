=====
Usage
=====

To use robopython in a project::

| import robopython
| OR
| from robopython import Robo
|
| my_robo = Robo("BLE_Name")
