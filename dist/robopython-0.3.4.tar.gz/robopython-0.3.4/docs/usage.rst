=====
Usage
=====

To use robopython in a project::

import robopython
OR
from robopython import Robo
