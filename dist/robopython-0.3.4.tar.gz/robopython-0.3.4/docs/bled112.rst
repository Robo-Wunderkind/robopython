=============
BLED112 Class
=============

Create BLED112 Instance::

	BLE = BLED112(com_port=None)
	The Robo Class initiates its own instance of BLED112 when initialized.

start()::

	Activates the connected BLED112 USB Dongle

stop()::
	
	Turns off BLED112 USB Dongle
