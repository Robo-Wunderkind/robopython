=======
History
=======

0.1.0 (2018-11-06)
------------------

* First release on PyPI.

0.3.4 (2018-11-12)
------------------

* Latest release on PyPI.
