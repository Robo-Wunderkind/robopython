=======
History
=======

0.1.0 (2018-11-06)
------------------

* First release on PyPI.

0.4.3 (2019-01-16)
------------------

* Latest release on PyPI.
